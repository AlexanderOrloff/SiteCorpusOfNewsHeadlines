# -*- coding: utf-8 -*-
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('Index.html')

@app.route('/annotation')
def annotation():
    return render_template('Annotation.html')

@app.route('/materials')
def materials():
    return render_template('Materials.html')

@app.route('/htu')
def htu():
    return render_template('How to Use.html')

if __name__ == '__main__':
    app.run(debug=True)